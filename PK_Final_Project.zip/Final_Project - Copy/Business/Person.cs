﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhumlaKamnandiMockup.Business
{
    public class Person
    {
       
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Email { get; set; }
        public int Age { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; } 

       
        public Person(string name, string surname, string email, int age, string phone, string address)
        {
            Name = name;
            Surname = surname;
            Email = email;
            Age = age;
            Phone = phone;
            Address = address;
        }
    }
}

