﻿namespace PhumlaKamnandiMockup.UserControls
{
    partial class ucCreateBooking03
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1BookingInvoice = new System.Windows.Forms.Panel();
            this.btnBack = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.txtTotalAmountTax = new System.Windows.Forms.MaskedTextBox();
            this.txtTax = new System.Windows.Forms.MaskedTextBox();
            this.txtDeposit = new System.Windows.Forms.MaskedTextBox();
            this.txtSubtotal = new System.Windows.Forms.MaskedTextBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtDate = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gpbGuestInformation = new System.Windows.Forms.GroupBox();
            this.txtNoOfRooms = new System.Windows.Forms.MaskedTextBox();
            this.txtStayDuration = new System.Windows.Forms.MaskedTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.MaskedTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtNoOfGuests = new System.Windows.Forms.MaskedTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.panel1BookingInvoice.SuspendLayout();
            this.panel1.SuspendLayout();
            this.gpbGuestInformation.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1BookingInvoice
            // 
            this.panel1BookingInvoice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1BookingInvoice.Controls.Add(this.btnBack);
            this.panel1BookingInvoice.Controls.Add(this.panel1);
            this.panel1BookingInvoice.Location = new System.Drawing.Point(0, 0);
            this.panel1BookingInvoice.Margin = new System.Windows.Forms.Padding(2);
            this.panel1BookingInvoice.Name = "panel1BookingInvoice";
            this.panel1BookingInvoice.Size = new System.Drawing.Size(721, 529);
            this.panel1BookingInvoice.TabIndex = 0;
            this.panel1BookingInvoice.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1BookingInvoice_Paint);
            // 
            // btnBack
            // 
            this.btnBack.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnBack.Location = new System.Drawing.Point(126, 47);
            this.btnBack.Margin = new System.Windows.Forms.Padding(2);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(42, 33);
            this.btnBack.TabIndex = 67;
            this.btnBack.Text = "←";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.txtTotalAmountTax);
            this.panel1.Controls.Add(this.txtTax);
            this.panel1.Controls.Add(this.txtDeposit);
            this.panel1.Controls.Add(this.txtSubtotal);
            this.panel1.Controls.Add(this.btnCancel);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txtDate);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.gpbGuestInformation);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.btnConfirm);
            this.panel1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.Location = new System.Drawing.Point(172, 47);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(372, 429);
            this.panel1.TabIndex = 66;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(35, 242);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 15);
            this.label8.TabIndex = 67;
            this.label8.Text = "Deposit due:";
            // 
            // txtTotalAmountTax
            // 
            this.txtTotalAmountTax.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtTotalAmountTax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTotalAmountTax.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtTotalAmountTax.Location = new System.Drawing.Point(198, 340);
            this.txtTotalAmountTax.Margin = new System.Windows.Forms.Padding(2);
            this.txtTotalAmountTax.Name = "txtTotalAmountTax";
            this.txtTotalAmountTax.ReadOnly = true;
            this.txtTotalAmountTax.Size = new System.Drawing.Size(127, 20);
            this.txtTotalAmountTax.TabIndex = 47;
            this.txtTotalAmountTax.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.txtTotalAmountTax_MaskInputRejected);
            // 
            // txtTax
            // 
            this.txtTax.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtTax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTax.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtTax.Location = new System.Drawing.Point(198, 316);
            this.txtTax.Margin = new System.Windows.Forms.Padding(2);
            this.txtTax.Name = "txtTax";
            this.txtTax.ReadOnly = true;
            this.txtTax.Size = new System.Drawing.Size(127, 20);
            this.txtTax.TabIndex = 48;
            this.txtTax.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.txtTax_MaskInputRejected);
            // 
            // txtDeposit
            // 
            this.txtDeposit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtDeposit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDeposit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtDeposit.Location = new System.Drawing.Point(198, 237);
            this.txtDeposit.Margin = new System.Windows.Forms.Padding(2);
            this.txtDeposit.Name = "txtDeposit";
            this.txtDeposit.ReadOnly = true;
            this.txtDeposit.Size = new System.Drawing.Size(127, 20);
            this.txtDeposit.TabIndex = 63;
            this.txtDeposit.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.txtDeposit_MaskInputRejected);
            // 
            // txtSubtotal
            // 
            this.txtSubtotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSubtotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSubtotal.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtSubtotal.Location = new System.Drawing.Point(198, 290);
            this.txtSubtotal.Margin = new System.Windows.Forms.Padding(2);
            this.txtSubtotal.Name = "txtSubtotal";
            this.txtSubtotal.ReadOnly = true;
            this.txtSubtotal.Size = new System.Drawing.Size(127, 20);
            this.txtSubtotal.TabIndex = 49;
            this.txtSubtotal.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.txtSubtotal_MaskInputRejected);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.IndianRed;
            this.btnCancel.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnCancel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnCancel.Location = new System.Drawing.Point(197, 376);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(146, 29);
            this.btnCancel.TabIndex = 66;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(21, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(167, 30);
            this.label5.TabIndex = 37;
            this.label5.Text = "Booking Invoice";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(42, 52);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 15);
            this.label4.TabIndex = 36;
            this.label4.Text = "Booking date:";
            // 
            // txtDate
            // 
            this.txtDate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDate.ForeColor = System.Drawing.SystemColors.Info;
            this.txtDate.Location = new System.Drawing.Point(197, 52);
            this.txtDate.Margin = new System.Windows.Forms.Padding(2);
            this.txtDate.Name = "txtDate";
            this.txtDate.ReadOnly = true;
            this.txtDate.Size = new System.Drawing.Size(127, 20);
            this.txtDate.TabIndex = 39;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(26, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 15);
            this.label1.TabIndex = 41;
            this.label1.Text = "Guest Information:";
            // 
            // gpbGuestInformation
            // 
            this.gpbGuestInformation.Controls.Add(this.txtNoOfRooms);
            this.gpbGuestInformation.Controls.Add(this.txtStayDuration);
            this.gpbGuestInformation.Controls.Add(this.label2);
            this.gpbGuestInformation.Controls.Add(this.txtName);
            this.gpbGuestInformation.Controls.Add(this.label6);
            this.gpbGuestInformation.Controls.Add(this.label3);
            this.gpbGuestInformation.Controls.Add(this.label7);
            this.gpbGuestInformation.Controls.Add(this.txtNoOfGuests);
            this.gpbGuestInformation.Location = new System.Drawing.Point(28, 96);
            this.gpbGuestInformation.Margin = new System.Windows.Forms.Padding(2);
            this.gpbGuestInformation.Name = "gpbGuestInformation";
            this.gpbGuestInformation.Padding = new System.Windows.Forms.Padding(2);
            this.gpbGuestInformation.Size = new System.Drawing.Size(308, 130);
            this.gpbGuestInformation.TabIndex = 65;
            this.gpbGuestInformation.TabStop = false;
            // 
            // txtNoOfRooms
            // 
            this.txtNoOfRooms.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtNoOfRooms.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNoOfRooms.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtNoOfRooms.Location = new System.Drawing.Point(169, 96);
            this.txtNoOfRooms.Margin = new System.Windows.Forms.Padding(2);
            this.txtNoOfRooms.Name = "txtNoOfRooms";
            this.txtNoOfRooms.ReadOnly = true;
            this.txtNoOfRooms.Size = new System.Drawing.Size(128, 20);
            this.txtNoOfRooms.TabIndex = 65;
            // 
            // txtStayDuration
            // 
            this.txtStayDuration.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtStayDuration.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtStayDuration.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtStayDuration.Location = new System.Drawing.Point(169, 48);
            this.txtStayDuration.Margin = new System.Windows.Forms.Padding(2);
            this.txtStayDuration.Name = "txtStayDuration";
            this.txtStayDuration.ReadOnly = true;
            this.txtStayDuration.Size = new System.Drawing.Size(127, 20);
            this.txtStayDuration.TabIndex = 51;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(7, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 15);
            this.label2.TabIndex = 64;
            this.label2.Text = "Number of rooms:";
            // 
            // txtName
            // 
            this.txtName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtName.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtName.Location = new System.Drawing.Point(169, 24);
            this.txtName.Margin = new System.Windows.Forms.Padding(2);
            this.txtName.Name = "txtName";
            this.txtName.ReadOnly = true;
            this.txtName.Size = new System.Drawing.Size(127, 20);
            this.txtName.TabIndex = 40;
            this.txtName.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.txtName_MaskInputRejected);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(7, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 15);
            this.label6.TabIndex = 43;
            this.label6.Text = "Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(7, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 15);
            this.label3.TabIndex = 42;
            this.label3.Text = "Stay duration:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(7, 72);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(105, 15);
            this.label7.TabIndex = 44;
            this.label7.Text = "Number of guests:";
            // 
            // txtNoOfGuests
            // 
            this.txtNoOfGuests.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtNoOfGuests.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNoOfGuests.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtNoOfGuests.Location = new System.Drawing.Point(169, 72);
            this.txtNoOfGuests.Margin = new System.Windows.Forms.Padding(2);
            this.txtNoOfGuests.Name = "txtNoOfGuests";
            this.txtNoOfGuests.ReadOnly = true;
            this.txtNoOfGuests.Size = new System.Drawing.Size(128, 20);
            this.txtNoOfGuests.TabIndex = 46;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label11.Location = new System.Drawing.Point(35, 295);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 15);
            this.label11.TabIndex = 55;
            this.label11.Text = "Subtotal:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label10.Location = new System.Drawing.Point(35, 319);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 15);
            this.label10.TabIndex = 54;
            this.label10.Text = "Tax (15%):";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Location = new System.Drawing.Point(35, 344);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(138, 15);
            this.label9.TabIndex = 53;
            this.label9.Text = "Total Amount (Incl. Tax):";
            // 
            // btnConfirm
            // 
            this.btnConfirm.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnConfirm.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.btnConfirm.FlatAppearance.BorderSize = 0;
            this.btnConfirm.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnConfirm.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnConfirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfirm.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirm.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnConfirm.Location = new System.Drawing.Point(29, 376);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(144, 29);
            this.btnConfirm.TabIndex = 38;
            this.btnConfirm.Text = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = false;
            this.btnConfirm.Click += new System.EventHandler(this.btnContinue_Click);
            // 
            // ucCreateBooking03
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1BookingInvoice);
            this.Name = "ucCreateBooking03";
            this.Size = new System.Drawing.Size(721, 529);
            this.panel1BookingInvoice.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gpbGuestInformation.ResumeLayout(false);
            this.gpbGuestInformation.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1BookingInvoice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox txtDeposit;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.MaskedTextBox txtStayDuration;
        private System.Windows.Forms.MaskedTextBox txtTax;
        private System.Windows.Forms.MaskedTextBox txtTotalAmountTax;
        private System.Windows.Forms.MaskedTextBox txtNoOfGuests;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox txtName;
        private System.Windows.Forms.TextBox txtDate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.GroupBox gpbGuestInformation;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.MaskedTextBox txtSubtotal;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.MaskedTextBox txtNoOfRooms;
    }
}
