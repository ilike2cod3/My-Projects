﻿namespace PhumlaKamnandiMockup.UserControls
{
    partial class ucCheckAvailibility
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1Check = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.numericUpDownToddler = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownChild = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownAdult = new System.Windows.Forms.NumericUpDown();
            this.dateTimeBooking = new System.Windows.Forms.DateTimePicker();
            this.cmbSelectHotel = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnContinue = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1Check.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownToddler)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownChild)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAdult)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1Check
            // 
            this.panel1Check.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1Check.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1Check.Controls.Add(this.label9);
            this.panel1Check.Controls.Add(this.dateTimePicker1);
            this.panel1Check.Controls.Add(this.label8);
            this.panel1Check.Controls.Add(this.label7);
            this.panel1Check.Controls.Add(this.label6);
            this.panel1Check.Controls.Add(this.numericUpDownToddler);
            this.panel1Check.Controls.Add(this.numericUpDownChild);
            this.panel1Check.Controls.Add(this.numericUpDownAdult);
            this.panel1Check.Controls.Add(this.dateTimeBooking);
            this.panel1Check.Controls.Add(this.cmbSelectHotel);
            this.panel1Check.Controls.Add(this.label3);
            this.panel1Check.Controls.Add(this.label2);
            this.panel1Check.Controls.Add(this.label1);
            this.panel1Check.Controls.Add(this.label4);
            this.panel1Check.Controls.Add(this.label5);
            this.panel1Check.Controls.Add(this.btnContinue);
            this.panel1Check.Location = new System.Drawing.Point(188, 44);
            this.panel1Check.Name = "panel1Check";
            this.panel1Check.Size = new System.Drawing.Size(356, 429);
            this.panel1Check.TabIndex = 4;
            this.panel1Check.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1Check_Paint);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Location = new System.Drawing.Point(183, 95);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 15);
            this.label9.TabIndex = 34;
            this.label9.Text = "Check out:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Segoe UI Light", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(186, 114);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(117, 22);
            this.dateTimePicker1.TabIndex = 33;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(38, 280);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(93, 13);
            this.label8.TabIndex = 32;
            this.label8.Text = "Toddlers (0-3yrs)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(38, 254);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(95, 13);
            this.label7.TabIndex = 31;
            this.label7.Text = "Children (3-12yrs)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(38, 230);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 13);
            this.label6.TabIndex = 30;
            this.label6.Text = "Adults (12+yrs)";
            // 
            // numericUpDownToddler
            // 
            this.numericUpDownToddler.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.numericUpDownToddler.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDownToddler.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.numericUpDownToddler.Location = new System.Drawing.Point(144, 280);
            this.numericUpDownToddler.Name = "numericUpDownToddler";
            this.numericUpDownToddler.Size = new System.Drawing.Size(34, 16);
            this.numericUpDownToddler.TabIndex = 29;
            // 
            // numericUpDownChild
            // 
            this.numericUpDownChild.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.numericUpDownChild.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDownChild.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.numericUpDownChild.Location = new System.Drawing.Point(144, 254);
            this.numericUpDownChild.Name = "numericUpDownChild";
            this.numericUpDownChild.Size = new System.Drawing.Size(34, 16);
            this.numericUpDownChild.TabIndex = 28;
            // 
            // numericUpDownAdult
            // 
            this.numericUpDownAdult.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.numericUpDownAdult.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDownAdult.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.numericUpDownAdult.Location = new System.Drawing.Point(144, 227);
            this.numericUpDownAdult.Name = "numericUpDownAdult";
            this.numericUpDownAdult.Size = new System.Drawing.Size(34, 16);
            this.numericUpDownAdult.TabIndex = 27;
            // 
            // dateTimeBooking
            // 
            this.dateTimeBooking.Font = new System.Drawing.Font("Segoe UI Light", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimeBooking.Location = new System.Drawing.Point(38, 114);
            this.dateTimeBooking.Name = "dateTimeBooking";
            this.dateTimeBooking.Size = new System.Drawing.Size(117, 22);
            this.dateTimeBooking.TabIndex = 26;
            // 
            // cmbSelectHotel
            // 
            this.cmbSelectHotel.BackColor = System.Drawing.Color.Gray;
            this.cmbSelectHotel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmbSelectHotel.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSelectHotel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cmbSelectHotel.FormattingEnabled = true;
            this.cmbSelectHotel.Location = new System.Drawing.Point(38, 166);
            this.cmbSelectHotel.Name = "cmbSelectHotel";
            this.cmbSelectHotel.Size = new System.Drawing.Size(265, 24);
            this.cmbSelectHotel.TabIndex = 25;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(36, 206);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(135, 13);
            this.label3.TabIndex = 24;
            this.label3.Text = "Select number of guests:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(36, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 15);
            this.label2.TabIndex = 23;
            this.label2.Text = "Check in:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(36, 148);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 15);
            this.label1.TabIndex = 19;
            this.label1.Text = "Select hotel:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(34, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(183, 15);
            this.label4.TabIndex = 20;
            this.label4.Text = "Please enter the following details:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(16, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(180, 30);
            this.label5.TabIndex = 21;
            this.label5.Text = "Check Availability";
            // 
            // btnContinue
            // 
            this.btnContinue.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnContinue.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.btnContinue.FlatAppearance.BorderSize = 0;
            this.btnContinue.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnContinue.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnContinue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnContinue.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContinue.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnContinue.Location = new System.Drawing.Point(41, 349);
            this.btnContinue.Name = "btnContinue";
            this.btnContinue.Size = new System.Drawing.Size(155, 29);
            this.btnContinue.TabIndex = 22;
            this.btnContinue.Text = "Continue";
            this.btnContinue.UseVisualStyleBackColor = false;
            this.btnContinue.Click += new System.EventHandler(this.btnContinue_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.panel1Check);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(721, 529);
            this.panel1.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI Black", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(131, 30);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(51, 50);
            this.button1.TabIndex = 33;
            this.button1.Text = "←";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ucCheckAvailibility
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ucCheckAvailibility";
            this.Size = new System.Drawing.Size(721, 529);
            this.panel1Check.ResumeLayout(false);
            this.panel1Check.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownToddler)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownChild)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAdult)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1Check;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown numericUpDownToddler;
        private System.Windows.Forms.NumericUpDown numericUpDownChild;
        private System.Windows.Forms.NumericUpDown numericUpDownAdult;
        private System.Windows.Forms.DateTimePicker dateTimeBooking;
        private System.Windows.Forms.ComboBox cmbSelectHotel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnContinue;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label9;
    }
}
