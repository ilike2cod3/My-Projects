﻿namespace PhumlaKamnandiMockup.Properties
{
    internal sealed partial class Settings : global::System.Configuration.ApplicationSettingsBase
    {
        private static Settings defaultInstance = ((Settings)(global::System.Configuration.ApplicationSettingsBase.Synchronized(new Settings())));

        public static Settings Default
        {
            get
            {
                return defaultInstance;
            }
        }

        [global::System.Configuration.ApplicationScopedSettingAttribute()]
        [global::System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [global::System.Configuration.SpecialSettingAttribute(global::System.Configuration.SpecialSetting.ConnectionString)]
        [global::System.Configuration.DefaultSettingValueAttribute("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\DELL\\OneDrive\\Deskto" +
            "p\\PROJECT_WITH_FORMS2(3)\\PROJECT_WITH_FORMS\\PhumlaK_Hotel.mdf;Integrated Securit" +
            "y=True;Connect Timeout=30;")]
        public string Phumla_KConnectionString
        {
            get
            {
                return ((string)(this["Phumla_KConnectionString"]));
            }
        }
    }
}
