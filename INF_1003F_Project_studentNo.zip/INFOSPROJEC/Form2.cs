﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace INFOSPROJEC
{
    public partial class VehicleSales : Form
    {
        public VehicleSales()
        {
            InitializeComponent();
            radbtnStandard.Checked = true; // assuming standard is the default
        }

        public class Calculations
        {

            public double CalcSubtotal(double a, double b, double c, double d)
            {
                return a + b + c;
            }

            public double SalesTax(double a, double b, double c,double d)
            {
                return (a + b + c + d) * 0.08; // 8% tax rate
            }

            public double Total(double a, double b, double c, double d)
            {
                return (a + b + c + d) * 1.08 ; // Including tax
            }

            public double AmtDue(double a, double b, double c,double d)
            {
                return (a + b + c + d) * 1.08 - c; // Subtracting trade-in allowance
            }
        }
        //method for performing calculations
        private void PerformCalculations()
        {
            double carSalesPrice;
            double tradeAllowance;
            double accessoriesAmount = 0;
            double exteriorFinish = 0;
            

            if (chkStereoSystem.Checked)
            {
                accessoriesAmount += 5999;
            }
            if (chkLeatherInterior.Checked)
            {
                accessoriesAmount += 29999;
            }
            if (chkCompNav.Checked)
            {
                accessoriesAmount += 15900;
            }
            if (radbtnStandard.Checked)
            {
                exteriorFinish = 0;
            }
            if (radBtnPearlized.Checked)
            {
                exteriorFinish = 9999;
            }
            if (radbtnCustomDet.Checked)
            {
                exteriorFinish = 12999;
            }

            if (!double.TryParse(txtCarSalesPrice.Text, out carSalesPrice) || !double.TryParse(txtTradeAllowance.Text, out tradeAllowance))
            {
                MessageBox.Show("Invalid input format. Please enter valid numeric values.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit the method to prevent further processing
            }
            if (txtTradeAllowance.Text is null)
            {
                tradeAllowance = 0;
            }

            double subtotal = calculations.CalcSubtotal(accessoriesAmount, exteriorFinish, tradeAllowance,carSalesPrice);
            double salesTax = calculations.SalesTax(accessoriesAmount, exteriorFinish, tradeAllowance, carSalesPrice);
            double total = calculations.Total(accessoriesAmount, exteriorFinish, tradeAllowance, carSalesPrice);
            double amtDue = calculations.AmtDue(accessoriesAmount, exteriorFinish, tradeAllowance, carSalesPrice);

            txtSubtotal.Text = subtotal.ToString();
            txtTotal.Text = total.ToString();
            txtSalesTax.Text = salesTax.ToString();
            txtAmtDue.Text = amtDue.ToString();
            txtAccFin.Text = accessoriesAmount.ToString();
        }
        private Calculations calculations = new Calculations();

        
        //method for clearing text boxes
        private void ClearBoxes()
        {
            // Clear text boxes
            txtCarSalesPrice.Text = "";
            txtTradeAllowance.Text = "";
            txtSubtotal.Text = "";
            txtSalesTax.Text = "";
            txtTotal.Text = "";
            txtAmtDue.Text = "";
            txtAccFin.Text = "";

            // Reset checkboxes and radio buttons
            chkStereoSystem.Checked = false;
            chkLeatherInterior.Checked = false;
            chkCompNav.Checked = false;
            radbtnStandard.Checked = true; // assuming standard is the default
            radBtnPearlized.Checked = false;
            radbtnCustomDet.Checked = false;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearBoxes();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            PerformCalculations();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void calculateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PerformCalculations();
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ClearBoxes();
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            string text = "Car Sales Price: " + txtCarSalesPrice.Text + "\n" +
                                 "Trade Allowance: " + txtTradeAllowance.Text + "\n" +
                                 "Subtotal: " + txtSubtotal.Text + "\n" +
                                 "Sales Tax: " + txtSalesTax.Text + "\n" +
                                 "Total: " + txtTotal.Text + "\n" +
                                 "Amount Due: " + txtAmtDue.Text;
            Font printFont = new System.Drawing.Font
            ("Arial", 35, System.Drawing.FontStyle.Regular);
            // Draw the string .
            e.Graphics.DrawString(text, printFont,
            Brushes.Black, 10, 10);
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string message = "Enter the price of your var value and your trade in allowance (if applicable). Contact rondebosch@autocentre.co.za for more help";
            MessageBox.Show(message);
        }

        private void infoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            infoForm infoForm = new infoForm();
            //show infoform form
            infoForm.Show();
        }
    }
}
