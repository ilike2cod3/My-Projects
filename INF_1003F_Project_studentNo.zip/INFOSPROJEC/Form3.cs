﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace INFOSPROJEC
{
    public partial class AutoParts : Form
    {
        public AutoParts()
        {
            InitializeComponent();
            radBrandA.Checked = true; // assuming brand a is the default
        }
        private void LookupBrand(string[,] brandLookupTable)
        {
            string usernumber = txtUserNum.Text;
            bool found = false;

            for (int i = 0; i < brandLookupTable.GetLength(1); i++)
            {
                if (usernumber == brandLookupTable[1, i])
                {
                    txtOutput.Text = brandLookupTable[0, i];
                    found = true;
                    break; // Exit loop since the part number is found
                }
            }

            if (!found)
            {
                // Item not found, display error message
                MessageBox.Show($"Item {usernumber} not found in the lookup table. Please contact rondebosch@autocentre.co.za if you think this is an error.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnLookup_Click(object sender, EventArgs e)
        {
            if (radBrandA.Checked)

            {

                string[,] brandALookupTable = new string[,]

                {

            // RAC

            {"PR214", "PR223", "PR224", "PR246", "PR247", "PR248", "PR324", "PR326", "PR444"},

            // Brand A

            {"MR43T", "R43", "R43N", "R46N", "R46TS", "R46TX", "S46", "SR46E", "47L"}

                     };



                LookupBrand(brandALookupTable);

            }
            else if (radBrandC.Checked)
            {
                string[,] brandCLookupTable = new string[,]

                {

                // RAC

                 { "PR214", "PR223", "PR224", "PR246", "PR247", "PR248", "PR324", "PR326", "PR444" },

                //Brand C

                 { "RBL8", "RJ6", "RN4", "RN8", "RBL17Y", "RBL12-6", "J11", "XEJ8", "H12" }
                };
                LookupBrand(brandCLookupTable);
            }
            else if (radBrandX.Checked)
            {


                string[,] brandXLookupTable = new string[,]
                   {
            // RAC
                 {"PR214", "PR223", "PR224", "PR246", "PR247", "PR248", "PR324", "PR326", "PR444"},
                // Brand X
             {"14K22", "14K24", "14K30", "14K44", "14K33", "14K35", "14K38", "14K40", "14K44"}
                       };

                LookupBrand(brandXLookupTable);



            


                   








                
            }
        }
       
        private void btnClear_Click(object sender, EventArgs e)
            {
                txtUserNum.Text = string.Empty;
                txtOutput.Text = string.Empty;
            }

            private void btnExit_Click(object sender, EventArgs e)
            {
                this.Close();
            }
        }
    } 

