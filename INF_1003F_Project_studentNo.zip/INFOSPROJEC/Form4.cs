﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace INFOSPROJEC
{
    public partial class CarWash : Form
    {
        public CarWash()
        {
            InitializeComponent();
        }

        private const string StandardInterior = "Fragrance";
        private const string StandardExterior = "Hand wash";

        private const string DeluxeInterior = "Shampoo Carpets, Fragrance";
        private const string DeluxeExterior = "Hand wax, Hand Wash";

        private const string ExecutiveInterior = "Interior protection coats, Fragrance, Shampoo Carpets, Interior Protection Coat";
        private const string ExecutiveExterior = "Check engine fluids, Hand wax, Hand Wash";

        private const string LuxuryInterior = "Scotchgard, Shampoo Carpets, Fragrance, Shampoo Upholstery";
        private const string LuxuryExterior = "Detail undercarriage, Check engine fluids, Hand wax, Hand Wash, Detail Undercarriage";


        private void AddItemsToLists(string interiorItems, string exteriorItems)
        {
            // Add interior items to the interiorListBox
            foreach (string item in interiorItems.Split(','))
            {
                interiorListBox.Items.Add(item.Trim());
            }

            // Add exterior items to the exteriorListBox
            foreach (string item in exteriorItems.Split(','))
            {
                exteriorListBox.Items.Add(item.Trim());
            }
        }



        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            // Get the selected package
            string selectedPackage = listboxpackage.SelectedItem as string;

            // Clear the existing items in the lists
            interiorListBox.Items.Clear();
            exteriorListBox.Items.Clear();

            // Populate the lists based on the selected package
            switch (selectedPackage)
            {
                case "Standard":
                    AddItemsToLists(StandardInterior, StandardExterior);
                    break;
                case "Deluxe":
                    AddItemsToLists(DeluxeInterior, DeluxeExterior);
                    break;
                case "Executive":
                    AddItemsToLists(ExecutiveInterior, ExecutiveExterior);
                    break;
                case "Luxury":
                    AddItemsToLists(LuxuryInterior, LuxuryExterior);
                    break;
                default:
                    // Handle the case where no package is selected
                    break;
            }


        }



    

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Clear both interior and exterior lists
            interiorListBox.Items.Clear();
            exteriorListBox.Items.Clear();
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();


        }
        private string DisplaySummary()
        {
            int itemsInter = interiorListBox.Items.Count;
            int itemsExt = exteriorListBox.Items.Count;
            string summary = "Your CarWash Order:\r\n";

            // Append interior items
            summary += "Interior Work:\r\n";
            for (int i = 0; i < itemsInter; i++)
            {
                summary += $"{interiorListBox.Items[i]}\r\n";
            }

            // Append exterior items
            summary += "Exterior Work:\r\n";
            for (int i = 0; i < itemsExt; i++)
            {
                summary += $"{exteriorListBox.Items[i]}\r\n";
            }

            return summary;

        }
        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            string text = DisplaySummary();
            Font printFont = new System.Drawing.Font
            ("Arial", 25, System.Drawing.FontStyle.Regular);
            // Draw the string .
            e.Graphics.DrawString(text, printFont,
            Brushes.Black, 10, 10);
        }
    }
}

