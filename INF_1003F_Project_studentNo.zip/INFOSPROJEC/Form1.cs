﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace INFOSPROJEC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnBuyVehicle_Click(object sender, EventArgs e)
        {
            // Create an instance of the VehicleSales form
            VehicleSales vehicleSalesForm = new VehicleSales();

            // Show the VehicleSales form
            vehicleSalesForm.Show();
        }

        private void btnAutoParts_Click(object sender, EventArgs e)
        {
           
            AutoParts autoPartsForm = new AutoParts();

            // Show the AutoParts form
            autoPartsForm.Show();

        }

        private void btnINF_Click(object sender, EventArgs e)
        {
            infoForm infoForm = new infoForm();
            //show infoform form
            infoForm.Show();
        }

        private void btnCarWash_Click(object sender, EventArgs e)
        {
            CarWash carWashForm = new CarWash();
            carWashForm.Show();
        }
    }
}
